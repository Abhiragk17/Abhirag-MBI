# trading-chart-react

A TradingView-style charting terminal as one React component. Give it OHLCV bars; you get candles and six other chart types, 29 drawing tools, ten indicators, events, bar replay, price alerts and live updates. The renderer is TradingView's open-source [lightweight-charts](https://github.com/tradingview/lightweight-charts).

```bash
npm i trading-chart-react
```

```tsx
import { TradingChart } from "trading-chart-react";
import "trading-chart-react/styles.css";

<TradingChart data={bars} symbol="RELIANCE" indicators={["ema", "rsi"]} height={620} />
```

`bars` is `{ time, open, high, low, close, volume }[]`. `time` may be unix seconds, milliseconds or an ISO/date string. You can also pass raw CSV or JSON text as `data`. Input is sorted, de-duplicated and validated, and gaps are never filled.

## Live data

Either let the array grow:

```tsx
const [bars, setBars] = useState(history);
// appending or updating the last bar is detected and applied incrementally, without a re-fit
socket.on("bar", (b) => setBars((prev) => [...prev, b]));
```

Or push through the ref, which is cheaper and also accepts trade ticks:

```tsx
const chart = useRef<TradingChartHandle>(null);
socket.on("trade", (t) => chart.current?.update({ time: t.ts, price: t.price, volume: t.qty }));

<TradingChart ref={chart} data={history} />
```

Ticks are folded into bars at the data's base interval, and those are aggregated into whatever timeframe is on screen. If the user has scrolled back into history, new bars don't move their view.

## Price alerts

Any horizontal line, ray, zone, trend line or channel has a bell in its toolbar. When a live price crosses an armed drawing, the chart shows a toast and calls `onAlert`:

```tsx
<TradingChart
  ref={chart}
  data={bars}
  onAlert={({ drawing, level, price, direction }) => notify(`${drawing.text} crossed ${direction} ${level}`)}
/>

// or arm one from code
chart.current?.addDrawing({ type: "hline", points: [{ time, price: 2900 }], alert: true, text: "Breakout" });
```

## Props

| Prop | Type | |
| --- | --- | --- |
| `data` | `Bar[] \| string` | Bars, or CSV/JSON text. |
| `symbol` | `string` | Shown in the legend; layouts are saved per symbol. |
| `events` | `EventInput[]` | `{ time, type: "earnings" \| "dividend" \| "split" \| "news" \| "buy" \| "sell", label?, value? }` |
| `interval` | `number` | Base interval in seconds. Detected when omitted. |
| `timeframe`, `chartType`, `indicators` | initial values | Used when the symbol has no saved layout. `indicators` takes `"rsi"` or `{ type, params, colors }`. |
| `theme` / `defaultTheme` / `onThemeChange` | `"dark" \| "light"` | Controlled or uncontrolled theme. |
| `accentColor` | `string` | Color of active tools and highlights. |
| `height`, `className`, `style` | | Size and placement. Default height is 600. |
| `features` | `Partial<ChartFeatures>` | Turn parts of the UI on or off: `topToolbar`, `drawingToolbar`, `bottomBar`, `legend`, `navigation`, `indicators`, `replay`, `objectTree`, `settings`, `layoutMenu`, `dataImport`, `contextMenu`. `COMPACT_FEATURES` is a preset for dashboards. |
| `persist` / `storageKey` | `"local" \| false \| PersistAdapter` | Where layouts, settings and events are saved. The default is localStorage under `storageKey` (`"tvc"`). |
| `settings` | `Partial<ChartSettings>` | Candle, grid, scale, format, volume and session-break settings. |
| `onCrosshairMove`, `onLayoutChange`, `onDrawingsChange`, `onTimeframeChange`, `onAlert` | callbacks | Mirror chart state into your app. |

## Ref handle

`update(barOrTick | array)`, `addIndicator(spec)`, `removeIndicator(id)`, `getIndicators()`, `addDrawing(d)`, `updateDrawing(id, patch)`, `removeDrawing(id)`, `getDrawings()`, `clearDrawings()`, `setTimeframe(id)`, `getTimeframes()`, `setChartType(t)`, `getLayout()`, `applyLayout(l)`, `undo()`, `redo()`, `fit()`, `resetView()`, `scrollToLatest()`, `startReplay()`, `screenshot(): Promise<Blob>`, and `controller` for direct access to the engine.

## Several charts on one page

Instances are independent:
- **Theme:** each chart has its own, set by a class on its root element.
- **Storage:** separate per chart when you give each a different `storageKey` or adapter.
- **Keyboard:** shortcuts go to the chart you last clicked. A chart that's alone on the page takes them straight away.

The stylesheet is scoped under `.tvc-root` and has no global reset, so it won't restyle your app.

## Saving somewhere else

```ts
const adapter: PersistAdapter = {
  get: (key) => cache[key] ?? null,          // synchronous read (prefetch into a cache)
  set: (key, value) => { cache[key] = value; api.save(key, value); },
  remove: (key) => { delete cache[key]; api.remove(key); },
};
<TradingChart persist={adapter} … />
```

## Without the component

The calculations are exported as plain functions:
- **Data:** `parseOhlcv`, `parseEvents`, `normalizeWithReport`, `resample`, `heikinAshi`, `detectInterval`
- **Indicators:** `sma`, `ema`, `wma`, `rsi`, `adx`, plus `INDICATORS[type].compute(bars, params, source)`
- **Live:** `mergeLiveBar`, `lastAggregate`, `tickToBar`
- **Alerts:** `alertLevels`
- **Samples:** `sampleBars` generates synthetic data for prototyping.

## Developing

```bash
npm run build        # dist/ (ESM, CJS, .d.ts) + dist/styles.css
npm run playground   # builds, then serves the playground at http://localhost:5199
```

Pages under `playground/`:
- `/`: the demo, with a simulated feed, alerts, the ref API, compact multiples and the API reference
- `/full.html`: a full-window terminal
- `/test.html`: the harness used by the e2e checks

## Limitations

- Times are shown in UTC.
- Undo/redo covers drawings; indicator, settings and event edits apply immediately.
- `PersistAdapter.get` must be synchronous.
- Freehand drawings can be moved and restyled but not resized.
- Alerts are evaluated on live updates (`update()` or a growing `data` array), not on historical data you load.
